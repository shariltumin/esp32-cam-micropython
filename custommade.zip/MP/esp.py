#!/usr/bin/python3

import time
import os
import subprocess

call = subprocess.call
Popen = subprocess.Popen
result = subprocess.check_output

os.environ["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
today = time.strftime('%Y%m%d')

# micropython root dir
mps_dir = os.getcwd()+'/'+today+'/micropython'
# get ESPIDF_SUPHASH_V3
res = result(['grep', 'ESPIDF_SUPHASH_V3', "%s/ports/esp32/Makefile" % mps_dir])
esp_hash = (res.decode().split('\n')[0]).split()[-1]
print(esp_hash)

call(['mkdir', 'ESPIDF'])
os.chdir('ESPIDF')
call(["pwd"])
print('Clone esp-idf in ESPIDF')
call(['git', 'clone', 'https://github.com/espressif/esp-idf.git'])
os.chdir('esp-idf')
call(["pwd"])
print('Checkout', esp_hash)
call(['git', 'checkout', esp_hash])
print('Submodule update')
call(['git', 'submodule', 'update', '--init', '--recursive'])
os.chdir('components')
call(["pwd"])
print('Clone esp32-camera under components')
call(['git', 'clone', 'https://github.com/espressif/esp32-camera.git'])
print('Done esp-idf directory is:')
os.chdir('../')
call(["pwd"])

