#!/usr/bin/python3

import time
import os
from subprocess import call

os.environ["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
home = os.getenv('HOME')
today = time.strftime('%Y%m%d')
mpp_dir = os.getcwd()+'/'+today+'/'+'micropython''/'+'ports'
mpc_dir = home+'/pCloudDrive/micropython/firmware'

print("Copy esp32-cam firmware")
mpf_dir = mpc_dir+'/esp32-cam'+'/'+today
call(['mkdir', mpf_dir])
mpb_f = mpp_dir+'/esp32-cam/build-GENERIC/firmware.bin'
call(['cp', mpb_f, mpf_dir])
print("Copy done")

print("Copy esp32 firmware")
mpf_dir = mpc_dir+'/esp32'+'/'+today
call(['mkdir', mpf_dir])
mpb_f = mpp_dir+'/esp32-my/build-GENERIC/firmware.bin'
call(['cp', mpb_f, mpf_dir])
print("Copy done")

print("Copy esp8266 firmware")
mpf_dir = mpc_dir+'/esp8266'+'/'+today
call(['mkdir', mpf_dir])
mpb_f = mpp_dir+'/esp8266-my/build-GENERIC/firmware-combined.bin'
call(['cp', mpb_f, mpf_dir])
print("Copy done")

print("Copy esp8266 (512K)firmware")
mpf_dir = mpc_dir+'/esp8266_512'+'/'+today
call(['mkdir', mpf_dir])
mpb_f = mpp_dir+'/esp8266-my/build-GENERIC_512K/firmware-combined.bin'
call(['cp', mpb_f, mpf_dir])
print("Copy done")

print("Copy unix micropython")
mpf_dir = mpc_dir+'/unix'+'/'+today
call(['mkdir', mpf_dir])
mpb_f = mpp_dir+'/unix/micropython'
call(['cp', mpb_f, mpf_dir])
call(['cp', mpb_f, home+'/bin/'])
print("Copy done")

print("Copy windows micropython")
mpf_dir = mpc_dir+'/windows'+'/'+today
call(['mkdir', mpf_dir])
mpb_f = mpp_dir+'/windows/micropython.exe'
call(['cp', mpb_f, mpf_dir])
print("Copy done")

