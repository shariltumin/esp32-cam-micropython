
from hashlib import sha256 as sha

class Crypt:
   def __init__(my, seed='', blk=0):
      if seed:
         my.seed = sha(seed).digest()
      else:
         my.seed = sha("Tgsf2kjf&MOtgeHs#34kk").digest()
      my.salt = sha("gsfT5#dskiTRa12@7sDQa").digest()
      my.key = sha(my.seed+my.salt).digest()
      my.left_brac = b'>>>>'
      my.right_brac = b'<<<<'
      my.blk = blk

   #def _xor(s1, s2):
   #   return ''.join(chr(ord(a) ^ ord(b)) for a,b in zip(s1,s2))

   def _xor(my, ba1, ba2):
      return bytes([_a ^ _b for _a, _b in zip(ba1, ba2)])

   def newkey(my, seed='', salt=''):
      new = False
      if seed:
         my.seed = sha(seed).digest()
         new = True
      if salt:
         my.salt = sha(salt).digest()
         new = True
      if new:
         my.key = sha(my.seed+my.salt).digest()

   def _cryp(my, mode, data):
      key = my.key
      p = 0
      dl = len(data)
      eb = bytes()
      while True:
         kl = len(key) 
         if p+kl > dl: # last block
            b = data[p:]
         else:
            b = data[p:p+kl]
         if b:
            en = my._xor(b, key[:len(b)])
            eb += en
            if mode == 'e':
               key = sha(my.seed+key+b).digest()
            else:
               key = sha(my.seed+key+en).digest()
         if len(b) < kl:
            if my.blk > 0:
               my.key = key
            break
         else:
            p += kl
      return eb

   def encrypt(my, data):
      if not data:
         return bytes()
      if type(data) == type("string"):
         data = data.encode("")  
      return my._cryp('e', data) # bytes type

   def decrypt(my, data):
      if not data:
         return bytes()
      if type(data) == type("string"):
         data = data.encode()    
      return my._cryp('d', data) # bytes type

   def encrypt_file(my, source, target, blk=80):
      fin = open(source, 'rb') 
      fout = open(target, 'wb') 
      my.blk = blk
      lb = my.left_brac
      rb = my.right_brac
      while True:
         l = fin.read(blk)
         lc = my.encrypt(l)   # 'a' gives 1 byte, 'Å' gives 2 bytes
         if len(lc) > len(l): # some iso-latin char?
            lc = lb+lc+rb
         fout.write(lc)
         if len(l) < blk: # we are done
            break
      fout.close()
      fin.close()

   def decrypt_file(my, source, target, blk=80):
      fin = open(source, 'rb') 
      fout = open(target, 'wb') 
      my.blk = blk
      lb = my.left_brac
      rb = my.right_brac
      rbc = rb[0]
      rbln = len(rb)
      while True:
         l = fin.read(blk)
         if l[:rbln] == lb:
            buf = l[rbln:]
            eom = 0
            # read until rb
            while True:
               ll = fin.read(1)
               buf += ll
               if ll == rbc:
                  eom += 1
                  if eom == rbln:
                    ln = my.decrypt(buf[:-rbln])
                    fout.write(ln)
                    break
         else:
            ln = my.decrypt(l)
            fout.write(ln)

         if len(l) < blk: # we are done
            break

      fout.close()
      fin.close()

