#define MICROPY_HW_BOARD_NAME "ESP32 module (camera)"
#define MICROPY_HW_MCU_NAME "ESP32"
