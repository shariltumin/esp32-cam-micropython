freeze('$(PORT_DIR)/modules', ('apa102.py', 'flashbdev.py', 'neopixel.py', 'port_diag.py', '_boot.py', 'inisetup.py', 'ntptime.py'))
# freeze('$(MPY_DIR)/tools', ('upip.py', 'upip_utarfile.py'))
freeze('$(MPY_DIR)/drivers/dht', 'dht.py')
freeze('$(MPY_DIR)/drivers/onewire')
freeze('$(MPY_DIR)/extra', 'CryptoXo.py')  # put your modules here
freeze('$(MPY_DIR)/extra', 'uasyncio.py')
