#!/usr/bin/python3

import time
import sys
import os
import subprocess 

call = subprocess.call
result = subprocess.check_output

os.environ["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
tpl_dir = os.getcwd()+'/Custommade_Template'
esp_idf = os.getcwd()+'/ESPIDF/esp-idf'

today = time.strftime('%Y%m%d')
# call(["ls", '-l'])
print("Make source directory", today)
call(['mkdir', today])
print("Change current directory to", today)
os.chdir(today)

print("Clone micropython in", today)
call(['git', 'clone', 'https://github.com/micropython/micropython.git'])
print("Cloning done")
mpy_dir = os.getcwd()+'/micropython'

print("Checking esp-idf")
# get ESPIDF_SUPHASH_V3
res = result(['grep', 'ESPIDF_SUPHASH_V3', "%s/ports/esp32/Makefile" % mpy_dir])
mp_esp_hash = (res.decode().split('\n')[0]).split()[-1]
# get  esp-idf hash
print("Change current directory to", esp_idf)
try:
   os.chdir(esp_idf)
except:
   print('You need esp-idf')
   print('Please run esp.py')
   print('Try again when done.')
   sys.exit(1)
res = result(['git', 'rev-parse', 'HEAD'])
esp_idf_hash = res.decode()[:-1] # strip newline
#print(type(mp_esp_hash), mp_esp_hash, '.')
#print(type(esp_idf_hash), esp_idf_hash, '.')
if mp_esp_hash != esp_idf_hash:
   print('You need esp-idf V3 with suphash %s' % mp_esp_hash)
   print('Please run esp.py')
   print('Try again when done.')
   sys.exit(1)
# Continue if OK
print("Change current directory to", mpy_dir)
os.chdir(mpy_dir)
print("Clone submodule in", mpy_dir)
call(['git', 'submodule', 'update', '--init', '--recursive'])
print("Cloning done")
print("Copying ports ..")
print("esp32 to esp32-cam")
call(['cp', '-r', 'ports/esp32', 'ports/esp32-cam'])
call(['cp', '-r', 'ports/esp32', 'ports/esp32-my'])
call(['cp', '-r', 'ports/esp8266', 'ports/esp8266-my'])
print("Copying done")
print("Patching custom files from", tpl_dir)
os.chdir(tpl_dir)
call(['cp', '-rfv', 'extra', mpy_dir]) 
call(['cp', '-rfv', 'ports', mpy_dir]) 
call(['cp', '-rfv', 'py', mpy_dir]) 
print("Patching done")
print("Change current directory to", mpy_dir)
os.chdir(mpy_dir)
print("Build mpy-cross")
call(['make', '-C', 'mpy-cross'])
print("Build done")
print("Setting up for esp32 build")
print("Set PATH")
os.environ["PATH"] = "/home/sharil/micropython/xtensa-esp32-elf/bin:/home/sharil/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
print("Set ESPIDF")

os.environ["ESPIDF"] = esp_idf
print("Build micropython for esp23-cam")
work_dir = mpy_dir+'/ports/esp32-cam'
print("Change current directory to", work_dir)
os.chdir(work_dir)
call(['make'])
print("Build done")

print("Build micropython for esp23")
work_dir = mpy_dir+'/ports/esp32-my'
print("Change current directory to", work_dir)
os.chdir(work_dir)
call(['make'])
print("Build done")

print("Setting up for esp8266 build")
print("Set PATH")
os.environ["PATH"] = "/home/sharil/micropython/esp-open-sdk/xtensa-lx106-elf/bin:/home/sharil/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
print("Build micropython for esp8266")
work_dir = mpy_dir+'/ports/esp8266-my'
print("Change current directory to", work_dir)
os.chdir(work_dir)
call(['make'])
print("Build done")

print("Build micropython for esp8266-512K")
call(['make', 'BOARD=GENERIC_512K'])
print("Build done")

work_dir = mpy_dir+'/ports/unix'
print("Change current directory to", work_dir)
print("Build micropython for unix")
os.chdir(work_dir)
call(['make', 'submodules'])
call(['make'])
print("Build done")

work_dir = mpy_dir+'/ports/windows'
print("Change current directory to", work_dir)
print("Build micropython for windows")
os.chdir(work_dir)
call(['make', 'CROSS_COMPILE=i686-w64-mingw32-'])
print("Build done")
print("Run mpc.py if you want to copy firmwares to staging area.")


