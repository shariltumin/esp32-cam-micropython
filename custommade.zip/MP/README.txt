
To build micropython custom ports do:
$ ./mpb.py  

When done the files will be copied to staging disk:
$ ./mpc.py


While running mpb.py we might have errors, a git server is down for example.

fatal: unable to access 'https://git.savannah.gnu.org/r/lwip.git/': Failed to connect to git.savannah.gnu.org port 443: Connection refused

fatal: clone of 'https://git.savannah.gnu.org/r/lwip.git' into submodule path '/home/sharil/MP/20191206/micropython/lib/lwip' failed

We will not be able to build micropython that depends on lwip. A recursive copy
(cp -r) of lib/lwip from the previous successful build directory will help. You can try that, then try to run mpb.py

Or you can wait until the git server is up again, usually, it will not take a long time until the server will be up.

